import ISorvete from "./ISorvete";

export class SorveteBaunilha implements ISorvete {
  fazer(): string {
    return "Sorvete de Baunilha";
  }
}
  