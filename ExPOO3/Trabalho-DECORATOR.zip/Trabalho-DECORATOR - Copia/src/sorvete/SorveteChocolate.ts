import ISorvete from "./ISorvete";

export class SorveteChocolate implements ISorvete {
  fazer(): string {
    return "Sorvete de Chocolate";
  }
}
  