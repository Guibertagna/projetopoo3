export default interface ISorvete{
    fazer() : string;
   
}



